# Norse Mythos Card Game - Installation & Download Guide

## Download Options

This project contains over 1,500 files and 261MB of assets. For your convenience, we offer several download options:

### Option 1: Automated Download (Recommended)

The repository includes a GitHub workflow that automatically downloads all project files:

1. Go to the Actions tab in the GitHub repository
2. Select the "Download All Files Workflow"
3. Click "Run workflow" and select your preferred download option:
   - `all` - Complete project (261MB, all 1,568 files)
   - `key_components` - Essential card components only (28KB)
   - `source_only` - Source code without assets (131MB)
4. Wait for the workflow to complete and download the artifact

### Option 2: Direct Downloads

You can directly download the archives from the [Releases page](https://github.com/Dhenz14/norse-mythos-card-game/releases):

- `norse-mythos-everything-complete.tar.gz` (261MB) - Complete project with all 1,568 files
- `norse-mythos-key-components.tar.gz` (28KB) - Essential card components only
- `norse-mythos-archive.tar.gz` (131MB) - Source code archive

### Option 3: Clone Repository (Partial Files Only)

```bash
git clone https://github.com/Dhenz14/norse-mythos-card-game.git
```

This option only includes files directly pushed to the repository, not the complete project. For the full project, use Options 1 or 2.

## Installation Steps

1. Extract the downloaded archive
   ```bash
   tar -xzf norse-mythos-everything-complete.tar.gz
   cd norse-mythos-card-game
   ```

2. Install dependencies
   ```bash
   npm install
   ```

3. Start the development server
   ```bash
   npm run dev
   ```

4. Open your browser and navigate to `http://localhost:5173`

## Key Components

The most important files for understanding the holographic card system are:

- `client/src/components/CardFrame.tsx` - Main card component
- `client/src/components/BattlefieldCardFrame.tsx` - Optimized battlefield cards
- `client/src/game/components/HolographicCardEffect.tsx` - Base holographic effect
- `client/src/game/components/LegendaryCardEffect.tsx` - Gold legendary effect
- `client/src/game/hooks/useCardTransform.tsx` - Card transformation logic

## Card Design Implementation

### Holographic Effects

The project implements distinct holographic effects for different card rarities:

#### Legendary Cards (Gold Effect)
- Uses `LegendaryCardEffect.tsx` with gold holographic background
- Opacity set to 0.6
- Mix blend mode: color-dodge
- Brightness filter: 1.2-1.3x
- Animation: shine-gold

#### Epic Cards (Purple Effect)
- Uses `HolographicCardEffect.tsx` with purple prismatic background
- Opacity set to 0.75
- Mix blend mode: color-dodge  
- Animation: prismatic-shift with increased gradient intensity

### Card Transformation

Cards seamlessly transform from full size in hand to optimized compact versions (120x170px) when played onto the battlefield:

1. Hand cards use `CardFrame.tsx` with full details and larger size
2. When played, they transition to `BattlefieldCardFrame.tsx`
3. Transition is managed by `useCardTransform.tsx` hook
4. All text elements, badges, and icons scale proportionally

### Hex Badge System

Attack and health values are displayed in hexagonal badges positioned at the top of cards:
- Attack values: Orange/gold hexagons on the left
- Health values: Red hexagons on the right
- Badge size: 32px for hand cards, scaled down to 28px for battlefield cards

## Troubleshooting

If you encounter any issues:

1. Make sure you've downloaded the complete archive
2. Verify all dependencies are installed
3. Check that you have Node.js v16+ installed
4. For issues with card rendering, check browser console for WebGL errors